﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;


namespace AyurHealth.COM.Models
{
    public class AyurProducts
    {
        public int ID { get; set; }

        public string Name { get; set; }

        public string Brand { get; set; }

        public decimal UnitPrice { get; set; }

        public decimal Discount { get; set; }

        public int Quantity { get; set; }

        public string Diseases { get; set; }

        public string Description { get; set; }

        public DateTime ExpDate { get; set; }

        public string ImageUrl { get; set; }

        public int Status {  get; set; }

        public string Type { get; set; }



    }
}
