﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;



namespace AyurHealth.COM.Models
{
    public class Users
    {
        public int ID { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }

        public string Password { get; set; }
        public string Email { get; set; }
        public string Phone { get; set; }
       // public DateTime DOB { get; set; }

        public string CAddress { get; set; }
        public decimal Fund { get; set; }
        public string Type { get; set; }

        public string Status { get; set; }
        public DateTime CreatedOn { get; set; }

    }
}
