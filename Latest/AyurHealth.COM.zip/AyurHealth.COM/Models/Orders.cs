﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace AyurHealth.COM.Models
{
    public class Orders
    {

        public int ID { get; set; }

        public int UserID   { get; set; }

        public string OrderNo { get; set; }

        public decimal OrderTotal { get; set; }

        public string OrderStatus { get; set; }

    }
}
