﻿using Microsoft.AspNetCore.Identity;
using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Threading.Tasks;
using System.Data;

namespace AyurHealth.COM.Models
{
    public class DAL
    {
        public Response register(Users users, SqlConnection connection)
        {
            Response response = new Response();
            SqlCommand cmd = new SqlCommand("sp_register", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FirstName", users.FirstName);
            cmd.Parameters.AddWithValue("@LastName", users.LastName);
            cmd.Parameters.AddWithValue("@Password", users.Password);
            cmd.Parameters.AddWithValue("@Email", users.Email);
            cmd.Parameters.AddWithValue("@Phone", users.Phone);
            cmd.Parameters.AddWithValue("@DOB", users.DOB);
            cmd.Parameters.AddWithValue("@CAddress", users.CAddress);
            cmd.Parameters.AddWithValue("@Fund", 0);
            cmd.Parameters.AddWithValue("@Type", "Users");
            cmd.Parameters.AddWithValue("@Status", "Pending");
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0)
            {
                response.StatusCode = 200;
                response.StatusMessage = "User Registered Sucessfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "User Registration Failed";
            }

            return response;
        }

        public Response Login(Users users, SqlConnection connection)
        {
            SqlDataAdapter da = new SqlDataAdapter("sp_login", connection);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@Email", users.Email);
            da.SelectCommand.Parameters.AddWithValue("@Password", users.Password);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response response = new Response();
            Users user = new Users();
            if (dt.Rows.Count > 0)
            {
                user.ID= Convert.ToInt32(dt.Rows[0]["ID"]);
                user.FirstName = Convert.ToString(dt.Rows[0]["FirstName"]);
                user.LastName = Convert.ToString(dt.Rows[0]["LastName"]);
                user.Email = Convert.ToString(dt.Rows[0]["Email"]);
                user.Phone = Convert.ToString(dt.Rows[0]["Phone"]);
                user.CAddress = Convert.ToString(dt.Rows[0]["CAddress"]);
                user.Type = Convert.ToString(dt.Rows[0]["Type"]);
                response.StatusCode = 200;
                response.StatusMessage = "User is Valid";
                response.User= user;
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "User is Invalid";
                response.User = null;
            }
            return response;

        }

        public Response viewUser(Users users, SqlConnection connection) {

            SqlDataAdapter da = new SqlDataAdapter("p_viewUser", connection);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@ID", users.ID);
            DataTable dt = new DataTable();
            da.Fill(dt);
            Response response = new Response();
            Users user = new Users();   
            if (dt.Rows.Count > 0)
                {
                user.ID = Convert.ToInt32(dt.Rows[0]["ID"]);
                user.FirstName = Convert.ToString(dt.Rows[0]["FirstName"]);
                user.LastName = Convert.ToString(dt.Rows[0]["LastName"]);
                user.Email = Convert.ToString(dt.Rows[0]["Email"]);
                user.Phone = Convert.ToString(dt.Rows[0]["Phone"]);
                user.CAddress = Convert.ToString(dt.Rows[0]["CAddress"]);
                user.Type = Convert.ToString(dt.Rows[0]["Type"]);
                user.Fund = Convert.ToDecimal(dt.Rows[0]["Fund"]);
                user.CreatedOn = Convert.ToDateTime(dt.Rows[0]["CreatedOn"]);
                user.Password = Convert.ToString(dt.Rows[0]["Password"]);
                response.StatusCode = 200;
                response.StatusMessage = "User exists";
                response.User = user;
                }
            else
                {
                    response.StatusCode = 100;
                    response.StatusMessage = "User does not exists";
                    response.User = null;
            }
                return response;
            }
              
        public Response updateProfile(Users users,SqlConnection connection)
        {
            Response response = new Response();

            SqlCommand cmd = new SqlCommand("sp_updateProfile", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@FirstName", users.FirstName);
            cmd.Parameters.AddWithValue("@LastName", users.LastName);
            cmd.Parameters.AddWithValue("@Password", users.Password);
            cmd.Parameters.AddWithValue("@Email", users.Email);
            cmd.Parameters.AddWithValue("@Phone", users.Phone);
            cmd.Parameters.AddWithValue("@DOB", users.DOB);
            cmd.Parameters.AddWithValue("@CAddress", users.CAddress);
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0) { 
                response.StatusCode=200;
                response.StatusMessage = "Record Updated Sucessfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Some error occured. Try after Sometime.";
            }
            return response;
        }
   
        public Response addToCart(Cart cart, SqlConnection connection)
        {
            Response response = new Response();
            SqlCommand cmd = new SqlCommand("sp_addToCart", connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@UserID", cart.UserID);
            cmd.Parameters.AddWithValue("@ProductID", cart.ProductID);
            cmd.Parameters.AddWithValue("@UnitPrice", cart.UnitPrice);
            cmd.Parameters.AddWithValue("@Discount", cart.Discount);
            cmd.Parameters.AddWithValue("@Quantity", cart.Quantity);
            cmd.Parameters.AddWithValue("@TotalPrice", cart.TotalPrice);
            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0) {
                response.StatusCode = 200;
                response.StatusMessage = "Item Added Sucessfully";

            } else {
                response.StatusCode = 100;
                response.StatusMessage = "Item could not be Added";
            }
            return response;
        }

        public Response placeOrder(Users users, SqlConnection connection) { 
        
                Response response = new Response();
                SqlCommand cmd = new SqlCommand("sp_placeOrder", connection);
                cmd.CommandType= CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@ID", users.ID);
                connection.Open();
                int i = cmd.ExecuteNonQuery();
                connection.Close();
            if (i > 0) { 
                response.StatusCode= 200;
                response.StatusMessage = "Order has been Placed Successfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Order could not be Placed";
            }

                return response;
        }

        public Response orderList(Users users, SqlConnection connection) {
        
            Response response = new Response();
            List<Orders> ListOrder = new List<Orders>();
            SqlDataAdapter da = new SqlDataAdapter("sp_orderList", connection);
            da.SelectCommand.CommandType= CommandType.StoredProcedure;
            da.SelectCommand.Parameters.AddWithValue("@Type", users.Type);
            da.SelectCommand.Parameters.AddWithValue("@ID",users.ID);
            DataTable dt= new DataTable();
            da.Fill(dt);
            if(dt.Rows.Count > 0)
            {
                for(int i = 0; i < dt.Rows.Count; i++)
                {
                    Orders order = new Orders();
                    order.ID = Convert.ToInt32(dt.Rows[i]["ID"]);
                    order.OrderNo = Convert.ToString(dt.Rows[i]["OrderNo"]);
                    order.OrderTotal = Convert.ToDecimal(dt.Rows[i]["OrderTotal"]);
                    order.OrderStatus = Convert.ToString(dt.Rows[i]["OrderStatus"]);
                    ListOrder.Add(order);
                }
                if(ListOrder.Count > 0)
                {
                    response.StatusCode = 200;
                    response.StatusMessage = "Order details Fetched";
                    response.ListOrders = ListOrder;
                }
                else
                {
                    response.StatusCode = 100;
                    response.StatusMessage = "Order details are not available";
                    response.ListOrders = null;
                }
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Order details are not available";
                response.ListOrders = null;
            }
            return response;
        }

        public Response addUpdateProduct(AyurProducts products, SqlConnection connection) { 
            
            Response response   = new Response();
            SqlCommand cmd = new SqlCommand("sp_addUpdateProduct",connection);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@Name",products.Name);
            cmd.Parameters.AddWithValue("@Brand", products.Brand);
            cmd.Parameters.AddWithValue("@UnitPrice", products.UnitPrice);
            cmd.Parameters.AddWithValue("@Discount", products.Discount);
            cmd.Parameters.AddWithValue("@Quantity", products.Quantity);
            cmd.Parameters.AddWithValue("@Diseases", products.Diseases);
            cmd.Parameters.AddWithValue("@Description", products.Description);
            cmd.Parameters.AddWithValue("@ExpDate", products.ExpDate);
            cmd.Parameters.AddWithValue("@ImageUrl", products.ImageUrl);
            cmd.Parameters.AddWithValue("@Status", products.Status);
            //cmd.Parameters.AddWithValue("@Type", products.Type);

            connection.Open();
            int i = cmd.ExecuteNonQuery();
            connection.Close();
            if (i > 0) {
                response.StatusCode = 200;
                response.StatusMessage = "Product inserted Successfully";
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Product did not save. Try Again.";
            }
            return response;
        }

        public Response userList(SqlConnection connection)
        {

            Response response = new Response();
            List<Users> ListUsers = new List<Users>();
            SqlDataAdapter da = new SqlDataAdapter("sp_userList", connection);
            da.SelectCommand.CommandType = CommandType.StoredProcedure;
            DataTable dt = new DataTable();
            da.Fill(dt);
            if (dt.Rows.Count > 0)
            {
                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    Users user = new Users();
                    user.ID = Convert.ToInt32(dt.Rows[i]["ID"]);
                    user.FirstName = Convert.ToString(dt.Rows[i]["FirstName"]);
                    user.LastName = Convert.ToString(dt.Rows[i]["LastName"]);
                    user.Password = Convert.ToString(dt.Rows[i]["Password"]);
                    user.Email = Convert.ToString(dt.Rows[i]["Email"]);
                    user.Phone = Convert.ToString(dt.Rows[i]["Phone"]);
                    user.DOB = Convert.ToDateTime(dt.Rows[i]["DOB"]);
                    user.CAddress = Convert.ToString(dt.Rows[i]["CAddress"]);
                    user.Fund = Convert.ToDecimal(dt.Rows[i]["Fund"]);
                    user.Status = Convert.ToString(dt.Rows[i]["Status"]);
                    //user.CreatedOn = Convert.ToDateTime(dt.Rows[i]["CreatedOn"]);
                    ListUsers.Add(user);
                }
                if (ListUsers.Count > 0)
                {
                    response.StatusCode = 200;
                    response.StatusMessage = "Users details Fetched";
                    response.ListUsers = ListUsers;
                }
                else
                {
                    response.StatusCode = 100;
                    response.StatusMessage = "Users details are not available";
                    response.ListUsers = null;
                }
            }
            else
            {
                response.StatusCode = 100;
                response.StatusMessage = "Users details are not available";
                response.ListUsers = null;
            }
            return response;
        }
    }
} 
