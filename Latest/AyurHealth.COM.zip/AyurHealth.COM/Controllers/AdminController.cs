﻿using AyurHealth.COM.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AyurHealth.COM.Controllers;
using System.Data.SqlClient;


namespace AyurHealth.COM.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AdminController : ControllerBase
    {
        private readonly IConfiguration _configuration;

        public AdminController(IConfiguration configuration)
        {
            _configuration = configuration;
        }

        [HttpPost]
        [Route("addUpdateProduct")]
        public Response addUpdateProduct(AyurProducts products) { 
        
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("AyurCS").ToString());
            Response response = dal.addUpdateProduct(products, connection);
            return response;
        }

        [HttpGet]
        [Route ("userList")]
        public Response userList()
        {
            DAL dal = new DAL();
            SqlConnection connection = new SqlConnection(_configuration.GetConnectionString("AyurCS").ToString());
            Response response = dal.userList(connection);
            return response;
        }
    }
}
